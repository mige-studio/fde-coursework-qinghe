"""Independent CSV audit. Never imports a generated library, SQL, or product answer."""
import argparse
import calendar
import csv
import hashlib
import json
import logging
from collections import Counter, defaultdict
from pathlib import Path

from paid_reference import calculate as paid_month

RATIOS = {
    "avg_order_value": ("net_sales_cents", "valid_order_count", "cents_per_order"),
    "avg_buyer_value": ("net_sales_cents", "buyer_count", "cents_per_member"),
    "purchase_frequency": ("valid_order_count", "buyer_count", "orders_per_member"),
    "refund_amount_rate": ("refund_cents", "payment_cents", "ratio"),
    "cancel_rate": ("cancelled_order_count", "order_count", "ratio"),
    "refund_order_rate": ("refund_order_count", "paid_order_count", "ratio"),
    "discount_rate": ("discount_cents", "gross_cents", "ratio"),
    "items_per_order": ("valid_order_items", "valid_order_count", "items_per_order"),
}


def unit(metric):
    if metric == "valid_order_items":
        return "items"
    if metric in RATIOS:
        return RATIOS[metric][2]
    if metric.endswith("_rate"):
        return "ratio"
    if metric == "monthly_paid_avg_order_value":
        return "cents_per_order"
    return "cents" if metric.endswith("_cents") else "count"


def valid(order):
    return order["status"] == "paid" and order["paid_cents"] > order["refund_cents"]


class Reference:
    def __init__(self, folder):
        self.folder = Path(folder)
        self.manifest = json.loads((self.folder / "manifest.json").read_text())
        self.tables = {}
        for name, key in [("members", "member_id"), ("orders", "order_id"),
                          ("stores", "store_id"), ("cards", "card_id")]:
            path = self.folder / (name + ".csv")
            if hashlib.sha256(path.read_bytes()).hexdigest() != self.manifest["sha256"][path.name]:
                raise ValueError("数据校验失败：" + path.name)
            with path.open(newline="", encoding="utf-8-sig") as stream:
                rows = list(csv.DictReader(stream))
            if len(rows) != self.manifest["counts"][name] or len({r[key] for r in rows}) != len(rows):
                raise ValueError("行数或唯一编号不符：" + name)
            for row in rows:
                for k in row:
                    if k.endswith("_cents") or k == "quantity":
                        row[k] = int(row[k])
            self.tables[name] = rows
        self.members = {r["member_id"]: r for r in self.tables["members"]}
        self.stores = {r["store_id"]: r for r in self.tables["stores"]}
        self.first = {}
        for o in self.tables["orders"]:
            if valid(o):
                candidate = (o["ordered_at"], o["order_id"])
                mid = o["member_id"]
                self.first[mid] = min(candidate, self.first.get(mid, candidate))
        logging.info("已独立读取数据 | version=%s counts=%s", self.manifest["id"], self.manifest["counts"])

    def dim(self, row, field, registration=False):
        member = row if registration else self.members[row["member_id"]]
        if field == "member":
            return member["member_id"]
        if field == "member__tier":
            return member["tier"]
        if field.startswith("metric_time__"):
            date = row["registered_at" if registration else "ordered_at"]
            return date[:7] + "-01" if field.endswith("month") else date
        if field.startswith("home_store"):
            store = self.stores[member["home_store_id"]]
            return store[field.split("__")[1]] if "__" in field else store["store_id"]
        if field.startswith("store"):
            store = self.stores[row["store_id"]]
            return store[field.split("__")[1]] if "__" in field else store["store_id"]
        if field.startswith("order__"):
            return row[field.split("__")[1]]
        raise ValueError("未知维度：" + field)

    def aggregate_orders(self, rows):
        paid = [r for r in rows if r["status"] == "paid"]
        good = [r for r in paid if valid(r)]
        refunded = [r for r in paid if r["refund_cents"] > 0]
        first = [r for r in good if (r["ordered_at"], r["order_id"]) == self.first[r["member_id"]]]
        values = {
            "order_count": len(rows), "paid_order_count": len(paid),
            "valid_order_count": len(good), "cancelled_order_count": sum(r["status"] == "cancelled" for r in rows),
            "refund_order_count": len(refunded),
            "partial_refund_order_count": sum(0 < r["refund_cents"] < r["paid_cents"] for r in paid),
            "full_refund_order_count": sum(r["paid_cents"] > 0 and r["refund_cents"] == r["paid_cents"] for r in paid),
            "payment_cents": sum(r["paid_cents"] for r in paid),
            "refund_cents": sum(r["refund_cents"] for r in paid),
            "net_sales_cents": sum(r["paid_cents"] - r["refund_cents"] for r in paid),
            "gross_cents": sum(r["gross_cents"] for r in paid),
            "discount_cents": sum(r["gross_cents"] - r["paid_cents"] for r in paid),
            "buyer_count": len({r["member_id"] for r in good}),
            "refund_buyer_count": len({r["member_id"] for r in refunded}),
            "selling_store_count": len({r["store_id"] for r in good}),
            "valid_order_items": sum(r["quantity"] for r in good),
            "first_buyer_count": len({r["member_id"] for r in first}),
            "first_order_count": len(first),
            "first_order_sales_cents": sum(r["paid_cents"] - r["refund_cents"] for r in first),
            "repeat_order_count": len(good) - len(first),
        }
        for name, (numerator, denominator, _) in RATIOS.items():
            values[name] = values[numerator] / values[denominator] if values[denominator] else None
        return values

    def answer(self, intent):
        start, end = intent["start"], intent["end"]
        if not self.manifest["coverage"][0] <= start < end <= self.manifest["coverage"][1]:
            raise ValueError("期望超出数据覆盖，不能当作零")
        metrics, groups, filters = intent["metrics"], intent["group_by"], intent["filters"]
        if any(m.startswith("monthly_") for m in metrics):
            if start[-2:] != "01" or end[-2:] != "01" or filters or groups not in ([], ["metric_time__month"]):
                raise ValueError("月报范围错误")
            months = []
            current = start
            while current < end:
                months.append(current[:7])
                year, month = map(int, current[:7].split("-"))
                current = f"{year + (month == 12):04}-{month % 12 + 1:02}-01"
            if len(months) > 1 and not groups:
                raise ValueError("多月须逐月列出")
            result_rows = []
            for month in months:
                counts = Counter(r["member_id"] for r in self.tables["orders"]
                                 if r["ordered_at"].startswith(month + "-") and valid(r))
                values = {"monthly_buyer_count": len(counts),
                          "monthly_repeat_buyer_count": sum(n >= 2 for n in counts.values())}
                values["monthly_repeat_rate"] = values["monthly_repeat_buyer_count"] / len(counts) if counts else None
                values.update(paid_month(self.tables["cards"], self.tables["orders"], month)["metrics"])
                result_rows.append(([month + "-01"] if groups else []) + [values[m] for m in metrics])
        else:
            registration = metrics == ["new_member_count"]
            if "new_member_count" in metrics and not registration:
                raise ValueError("注册指标单独核对其注册日期")
            buckets = defaultdict(list)
            date_key = "registered_at" if registration else "ordered_at"
            for row in self.tables["members" if registration else "orders"]:
                if not start <= row[date_key] < end:
                    continue
                if any(self.dim(row, f["field"], registration) not in
                       (f["value"] if f["op"] == "in" else [f["value"]]) for f in filters):
                    continue
                buckets[tuple(self.dim(row, g, registration) for g in groups)].append(row)
            if not groups:
                buckets.setdefault((), [])
            result_rows = []
            for keys, rows in sorted(buckets.items()):
                values = {"new_member_count": len(rows)} if registration else self.aggregate_orders(rows)
                result_rows.append(list(keys) + [values[m] for m in metrics])
        return {"status": "ok", "intent": intent, "columns": groups + metrics, "rows": result_rows,
                "units": {m: unit(m) for m in metrics}, "data_version": self.manifest["id"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", required=True)
    parser.add_argument("--spec", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | reference_all | %(message)s")
    reference = Reference(args.data)
    cases = json.loads(Path(args.spec).read_text())
    output = []
    for case in cases:
        expected = reference.answer(case["intent"]) if "intent" in case else case["expected"]
        output.append({"id": case["id"], "question": case["question"], "expected": expected,
                       "expected_source": {"method": "原始CSV逐行独立审核；先计算后问数，不导入被测模型、SQL或答案",
                                           "data": args.data, "hashes": reference.manifest["sha256"],
                                           "rules": "01订单日报、02财务、03周报、04统计邮件、05字典及本人W3小林/陈姐访谈",
                                           "review": case.get("review", "")}})
    path = Path(args.output)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as stream:
        json.dump(output, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    logging.info("独立期望保存 | cases=%s output=%s", len(output), args.output)


if __name__ == "__main__":
    main()
