"""从原始 CSV 独立复算六项月报，不读取生成指标库或产品答案。"""
import argparse
import calendar
import csv
import hashlib
import json
import re
from collections import defaultdict
from pathlib import Path


def eligible(card, day):
    """小林05920和陈姐05925/05927：开始含当天，结束不含当天。"""
    return (card["card_type"] in {"悦享年卡", "家庭季卡"}
            and card["valid_from"] <= day < card["valid_until"]
            and (not card["ended_at"] or day < card["ended_at"]))


def calculate(cards, orders, month):
    year, number = map(int, month.split("-"))
    day = f"{month}-{calendar.monthrange(year, number)[1]:02}"
    qualified = defaultdict(list)
    for card in cards:
        if eligible(card, day):
            qualified[card["member_id"]].append(card["card_id"])
    purchases = defaultdict(list)
    for order in orders:
        if (order["member_id"] in qualified and order["ordered_at"].startswith(month + "-")
                and order["status"] == "paid"
                and int(order["paid_cents"]) > int(order["refund_cents"])):
            purchases[order["member_id"]].append(order)
    buyers = len(purchases)
    count = sum(map(len, purchases.values()))
    sales = sum(int(o["paid_cents"]) - int(o["refund_cents"])
                for rows in purchases.values() for o in rows)
    repeats = sum(len(rows) >= 2 for rows in purchases.values())
    return {"month": month, "month_end": day, "eligible_members": sorted(qualified),
            "member_details": [{"member_id": member, "eligible_cards": qualified[member],
                                "order_ids": [o["order_id"] for o in purchases.get(member, [])],
                                "net_sales_cents": sum(int(o["paid_cents"]) - int(o["refund_cents"])
                                                       for o in purchases.get(member, []))}
                               for member in sorted(qualified)],
            "metrics": {"monthly_paid_buyer_count": buyers, "monthly_paid_order_count": count,
                        "monthly_paid_sales_cents": sales, "monthly_paid_repeat_buyer_count": repeats,
                        "monthly_paid_repeat_rate": repeats / buyers if buyers else None,
                        "monthly_paid_avg_order_value": sales / count if count else None}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--month", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", args.month):
        raise SystemExit("月份格式应为 YYYY-MM，例如 2026-08。")
    manifest = json.loads((args.data / "manifest.json").read_text())
    year, month = map(int, args.month.split("-"))
    start = f"{year:04}-{month:02}-01"
    end = f"{year + (month == 12):04}-{month % 12 + 1:02}-01"
    if not (manifest["coverage"][0] <= start < end <= manifest["coverage"][1]):
        raise SystemExit("查询月份超出数据覆盖，不能当作零。")
    tables = {}
    for name in ["cards", "orders"]:
        source = args.data / (name + ".csv")
        if hashlib.sha256(source.read_bytes()).hexdigest() != manifest["sha256"][source.name]:
            raise SystemExit("原数据校验失败：" + source.name)
        with source.open(newline="", encoding="utf-8-sig") as stream:
            tables[name] = list(csv.DictReader(stream))
        key = "card_id" if name == "cards" else "order_id"
        if len({row[key] for row in tables[name]}) != len(tables[name]):
            raise SystemExit("发现重复主键：" + key)
    result = calculate(tables["cards"], tables["orders"], args.month)
    result.update(data_version=manifest["id"], source_sha256=manifest["sha256"],
                  calculation="Python逐行复算；独立于dbt和模型生成结果")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps(result["metrics"], ensure_ascii=False))


if __name__ == "__main__":
    main()
