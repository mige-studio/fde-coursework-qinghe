"""Compare expected and actual evidence without models, SQL, or network access."""
import json
import math
import sys
from datetime import datetime


def compare(expected, actual):
    differences = []
    def check(path, wanted, got):
        if isinstance(wanted, (int, float)) and not isinstance(wanted, bool):
            ok = (isinstance(got, (int, float)) and not isinstance(got, bool)
                  and math.isfinite(got) and math.isfinite(wanted)
                  and (got == wanted if isinstance(wanted, int) else
                       math.isclose(wanted, got, rel_tol=1e-10, abs_tol=1e-10)))
        else:
            ok = type(wanted) is type(got) and wanted == got
        if not ok:
            differences.append({"path": path, "expected": wanted, "actual": got})

    if not isinstance(expected, dict) or not isinstance(actual, dict):
        return {"passed": False, "differences": [{"path": "root", "reason": "object required"}]}
    check("status", expected.get("status"), actual.get("status"))
    if expected.get("status") == "ok":
        for key in ("intent", "columns", "rows", "units"):
            if key not in actual:
                differences.append({"path": key, "reason": "required field missing"})
        wanted_intent, got_intent = expected.get("intent", {}), actual.get("intent", {})
        if not isinstance(wanted_intent, dict) or not isinstance(got_intent, dict):
            return {"passed": False, "differences": differences + [{"path": "intent", "reason": "object required"}]}
        for key in ("start", "end", "metrics", "group_by", "filters"):
            wanted, got = wanted_intent.get(key), got_intent.get(key)
            if key in ("metrics", "group_by", "filters") and isinstance(wanted, list) and isinstance(got, list):
                wanted = sorted(json.dumps(x, sort_keys=True) for x in wanted)
                got = sorted(json.dumps(x, sort_keys=True) for x in got)
            check("intent." + key, wanted, got)
        check("units", expected.get("units"), actual.get("units"))
        if "data_version" in expected:
            check("data_version", expected["data_version"], actual.get("data_version"))
        wc, gc = expected.get("columns", []), actual.get("columns", [])
        valid_columns = (isinstance(wc, list) and isinstance(gc, list)
                         and all(isinstance(c, str) for c in wc + gc)
                         and len(wc) == len(set(wc)) and len(gc) == len(set(gc))
                         and set(wc) == set(gc))
        if not valid_columns:
            differences.append({"path": "columns", "expected": wc, "actual": gc})
        else:
            wr, gr = expected.get("rows", []), actual.get("rows", [])
            valid_rows = (isinstance(wr, list) and isinstance(gr, list)
                          and all(isinstance(r, list) and len(r) == len(wc) for r in wr)
                          and all(isinstance(r, list) and len(r) == len(gc) for r in gr))
            if not valid_rows:
                differences.append({"path": "rows", "reason": "invalid row shape"})
            else:
                # Align columns and sort by dimension values, preserving duplicate rows.
                gr = [[row[gc.index(c)] for c in wc] for row in gr]
                dimensions = [i for i, c in enumerate(wc) if c not in wanted_intent.get("metrics", [])]
                row_key = lambda row: json.dumps([row[i] for i in dimensions], sort_keys=True)
                wr, gr = sorted(wr, key=row_key), sorted(gr, key=row_key)
                check("row_count", len(wr), len(gr))
                for i, (wrow, grow) in enumerate(zip(wr, gr)):
                    for col, wanted, got in zip(wc, wrow, grow):
                        if col.startswith("metric_time__") and isinstance(wanted, str) and isinstance(got, str):
                            try:
                                parsed = datetime.fromisoformat(got)
                                if parsed.hour == parsed.minute == parsed.second == parsed.microsecond == 0 and parsed.tzinfo is None:
                                    got = parsed.date().isoformat()
                            except ValueError:
                                pass
                        check(f"rows[{i}].{col}", wanted, got)
    elif expected.get("status") in ("unsupported", "clarify"):
        if not isinstance(actual.get("reason"), str) or not actual["reason"].strip():
            differences.append({"path": "reason", "reason": "explanation required"})
        if actual.get("rows"):
            differences.append({"path": "rows", "reason": "refusal must not return numeric results"})
    else:
        differences.append({"path": "expected.status", "reason": "invalid expected status"})
    return {"passed": not differences, "differences": differences}


if __name__ == "__main__":
    payload = json.load(sys.stdin)
    print(json.dumps(compare(payload["expected"], payload["actual"]), ensure_ascii=False))
