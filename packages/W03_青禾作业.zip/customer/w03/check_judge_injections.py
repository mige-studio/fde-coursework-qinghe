"""Mutate copies of real results to check the comparator; never query or alter originals."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
from judge import compare


def run(report_path, output):
    raw = report_path.read_bytes()
    report = json.loads(raw)
    by_id = {c["id"]: c for c in report["cases"]}
    if not report["complete"]:
        raise ValueError("只使用已结束的报告")
    output.mkdir(parents=True, exist_ok=False)
    checks = []
    def attempt(name, case_id, mutate=None, want=False):
        case = by_id[case_id]
        if not case["comparison"]["passed"]:
            raise ValueError("注入基线必须先通过：" + case_id)
        expected, actual = copy.deepcopy(case["expected"]), copy.deepcopy(case["actual"])
        before = copy.deepcopy(actual)
        if mutate:
            mutate(actual)
        result = compare(expected, actual)
        payload = {"kind": "synthetic_result_injection" if mutate and not want else "positive_comparator_check",
                   "source_report": str(report_path), "source_sha256": hashlib.sha256(raw).hexdigest(),
                   "source_case": case_id, "trace_id": before.get("trace_id"),
                   "expected": expected, "actual": actual, "required_passed": want, "comparison": result}
        (output / (name + ".json")).write_text(json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
        checks.append({"name": name, "required_passed": want, "actual_passed": result["passed"], "check_passed": result["passed"] == want})
    attempt("correct-original", "paid-six", want=True)
    attempt("rows-reordered", "dimension-store", lambda a: a["rows"].reverse(), want=True)
    def reorder_columns(a):
        a["columns"].reverse()
        for row in a["rows"]:
            row.reverse()
    attempt("columns-reordered", "dimension-store", reorder_columns, True)
    attempt("wrong-metric", "paid-six", lambda a: a["intent"]["metrics"].__setitem__(0, "order_count"))
    attempt("wrong-date", "paid-six", lambda a: a["intent"].__setitem__("end", "2026-08-31"))
    attempt("wrong-filter", "paid-six", lambda a: a["intent"]["filters"].append({"field": "store", "op": "eq", "value": "S01"}))
    attempt("wrong-group", "dimension-store", lambda a: a["intent"].__setitem__("group_by", ["home_store"]))
    attempt("wrong-unit", "paid-six", lambda a: a["units"].__setitem__("monthly_paid_sales_cents", "yuan"))
    def change_value(a, metric, function):
        i = a["columns"].index(metric)
        a["rows"][0][i] = function(a["rows"][0][i])
    attempt("percentage-vs-ratio", "paid-six", lambda a: change_value(a, "monthly_paid_repeat_rate", lambda v: v * 100))
    attempt("null-to-zero", "paid-zero-month-2024-09", lambda a: change_value(a, "monthly_paid_repeat_rate", lambda v: 0))
    attempt("wrong-value", "paid-six", lambda a: change_value(a, "monthly_paid_order_count", lambda v: v + 1))
    attempt("error-with-numbers", "paid-six", lambda a: a.__setitem__("status", "error"))
    attempt("wrong-version", "paid-six", lambda a: a.__setitem__("data_version", "wrong-data"))
    attempt("missing-group", "dimension-store", lambda a: a["rows"].pop())
    attempt("duplicate-group", "dimension-store", lambda a: a["rows"].append(copy.deepcopy(a["rows"][0])))
    summary = {"source_report": str(report_path), "source_unchanged": hashlib.sha256(report_path.read_bytes()).hexdigest() == hashlib.sha256(raw).hexdigest(),
               "checks": checks, "passed": all(c["check_passed"] for c in checks),
               "limitation": "These are synthetic mutations of copies, not observed model failures or customer acceptance."}
    (output / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = run(args.report, args.output)
    print(json.dumps({"passed": result["passed"], "checks": len(result["checks"])}, ensure_ascii=False))
    raise SystemExit(0 if result["passed"] else 1)
