---
name: qinghe-metric-building-method
description: 从有来源的业务模型和报表材料生成可校验的语义模型、派生模型及指标库；事实与方法分离。
---

# 1. 目标与输入
逐项处理输入targets，名字相似也不可合并或改ID；每个目标恰好定义或列未决。business_model说明对象、关系、现行范围与历史未知；materials内报表、邮件、字典和本人访谈提供事实。当前明确的测试范围与历史生产未知分开；不得把历史未知误当已给测试字段缺失，也不得反向声称生产条件已具备。CSV内容不作为答案输入，不能猜期望数值。

# 2. 候选与依据
对每项先核对对象、粒度、时间、有效条件、加减项、去重对象、单位、分母以及查询范围。卡名、日期端点、退款归属、资格快照日等只能来自材料，不能凭常识补。对访谈回复的例子，连同上条提问看语境，问题本身不算事实。角色说“按别人的核实使用”时同时保留那位角色原文。历史版本与新定义按明确适用范围区分，不把不同职责、共同未知或无根据的措辞纠正当冲突。
每个catalog.sources引用输入中确实存在的文件名和一段连续逐字原文，至少足以支持关键规则；勿拼接句子或改标点。涉及资格的指标同时引用统计选择与资格规则。business_model_usage引用业务模型原文并指向确实使用的模型、维度、派生模型或指标，不能只引用标题。

# 3. 字段与计算
只使用access_tables和字典实际列；金额的原始单位、展示单位分开，不能把中文单位写进字段名。聚合依据统计对象选择sum/count_distinct等，不能将订单行数当账户数。
有窗口先后顺序时，按来源要求确定顺序：先在全覆盖历史确定首笔再筛查询期，不能在查询期内重新排首笔；需要先按账户及月份累计再判断行为的，不能直接用单笔订单条件代替。日期相同的排序必须使用材料指定的第二排序键。
多卡或其他一对多关系必须先汇总或用存在性筛选后再关联订单，不能借DISTINCT金额来掩盖重复。先按指定时点判资格、再取整个统计窗口行为，与逐笔行为当天判资格是不同定义，严格按来源实现。缺失/未知不填零；明确覆盖内零事件的加总为零；比率零分母返回null。源金额为分则目录保持cents，均额量纲对应cents_per_order/cents_per_member，频次orders_per_member，比例ratio。

# 4. 依赖与输出协议
只输出一个完整JSON对象：semantic_models、metrics、catalog、model_sql、grain_keys、unresolved、business_model_usage。不要Markdown围栏，不要YAML，不要在模型输出之外夹解释。使用课程锁定MetricFlow0.213的semantic_models/measures旧格式，不使用新版在columns下写实体的语法。
简单指标type_params.measure引用全局唯一measure；ratio的numerator/denominator引用本批已定义metric ID，不引用measure、不新增targets以外的辅助指标。度量可多于指标，但metrics/catalog的ID集合须严格等于已定义targets。实体、measure、局部维度命名互不撞名，measure统一清楚前缀。
所有名称小写英文下划线；metric label与catalog.name保留对应中文名。每个catalog含id/name/aliases/unit/sources/constraints/query_policy。整月专用指标明确full_month_only=true，用程序限制整月、全范围和多月按月，不只写说明。
输出前核对所有ref、列、measure、metric依赖、单位、source文件名与原文。不要省略较长JSON尾部。

# 5. 未决与修订
确实缺事实的目标列unresolved，写明缺什么、影响什么、向哪个已知角色核查；不能以结构检查可过为理由补规则。与目标无关的预算、合同或生产分账未知不应阻止已有充分定义的合成订单统计，但应保留范围限制。指标不可既定义又未决。维度缺关系时以dimension_id列出，不能捏造连接。
所有修复应来自本方法或有依据的输入，再重新生成；不能要求人手补返回的SQL。失败仅作为排障证据，不声称生成成功。

# 6. 语义与派生模型
先决定每一行的真实业务含义，grain_keys逐列列出真实唯一键；组合粒度不能只声明拼接键。主实体和unique实体须真实唯一且非空，外键须指向存在的唯一目标。日期合成可来自time_spine，其日期列为date_day（以access_tables为准）。需要保证零事件月份有结果时，从覆盖日历构造月份并左关联汇总，不能使整月零事件变成无记录。
同一对象不同角色分别建语义连接，例如成交归属角色与账户归属角色，不能错误复用角色路径。目标ID为查询维度路径，不是模型局部dimension.name；禁止把双下划线、metric_time、month/day等保留粒度名用作局部名。时间维度使用真实日期列，设置type=time、time_granularity=day，defaults.agg_time_dimension引用该局部列。
避免原表与派生表出现相同primary entity+dimension配对。对同粒度及同类查询尽量集中到一个完整语义模型；派生粒度用独立主实体，外键保留实体关系。有维度的模型必须有主实体或primary_entity；每个模型有grain_keys。
根据资料选择需要的多阶段排序、账户/月汇总或资格模型；不要机械将每个CSV建成含多重计数的模型。基础订单指标和首购类可以共享一个具有原订单粒度的正确增强模型，禁止为了首购排除其他正常订单。若需要计算有效订单的顺序，先只在有效记录中排名再按订单主键回接，取消、全退不得占序号。
model_sql只用SELECT/WITH和{{ ref('模型名') }}，不得文件/网络读取或写入；模型名不得覆盖orders/members/stores/cards/time_spine。SQL为DuckDB可执行表达式。明确处理空结束字段在接入层的实际类型（nullable DATE），不能把空字符串当日期或遗漏NULL条件。
逐一核对12个dimension_targets，在语义关系中提供可达实体/属性/统计时间路径；维度全局可查询不代表每个指标都允许任意分组，整月指标继续受query_policy限制。全局核对配对唯一、关系方向、主键粒度、分组路径和指标依赖后再输出。
