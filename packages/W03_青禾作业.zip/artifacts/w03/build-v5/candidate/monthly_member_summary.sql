WITH month_calendar AS (
  SELECT DISTINCT
    date_trunc('month', date_day)::DATE AS month_start
  FROM {{ ref('time_spine') }}
),
member_month_valid AS (
  SELECT
    member_id,
    date_trunc('month', ordered_at)::DATE AS month_start,
    COUNT(*) AS valid_order_count
  FROM {{ ref('order_enhanced') }}
  WHERE is_valid
  GROUP BY member_id, date_trunc('month', ordered_at)::DATE
),
monthly_member_agg AS (
  SELECT
    month_start,
    COUNT(*) AS buyer_count,
    COUNT(*) FILTER (WHERE valid_order_count >= 2) AS repeat_buyer_count
  FROM member_month_valid
  GROUP BY month_start
)
SELECT
  c.month_start,
  COALESCE(a.buyer_count, 0) AS buyer_count,
  COALESCE(a.repeat_buyer_count, 0) AS repeat_buyer_count
FROM month_calendar c
LEFT JOIN monthly_member_agg a ON c.month_start = a.month_start