WITH valid_only AS (
  SELECT * FROM {{ ref('orders') }}
  WHERE status = 'paid' AND paid_cents - refund_cents > 0
),
ranked_valid AS (
  SELECT *, ROW_NUMBER() OVER (PARTITION BY member_id ORDER BY ordered_at, order_id) AS order_rank
  FROM valid_only
)
SELECT
  o.order_id,
  o.member_id,
  o.store_id,
  o.ordered_at,
  o.status,
  o.gross_cents,
  o.paid_cents,
  o.refund_cents,
  o.quantity,
  o.channel,
  m.home_store_id,
  m.tier AS member_tier,
  s.region AS store_region,
  s.store_name AS store_name,
  hs.region AS home_store_region,
  hs.store_name AS home_store_store_name,
  CASE WHEN o.status = 'paid' AND o.paid_cents - o.refund_cents > 0 THEN TRUE ELSE FALSE END AS is_valid,
  (o.paid_cents - o.refund_cents) AS net_cents,
  r.order_rank
FROM {{ ref('orders') }} o
LEFT JOIN ranked_valid USING(order_id)
LEFT JOIN {{ ref('members') }} m ON o.member_id = m.member_id
LEFT JOIN {{ ref('stores') }} s ON o.store_id = s.store_id
LEFT JOIN {{ ref('stores') }} hs ON m.home_store_id = hs.store_id