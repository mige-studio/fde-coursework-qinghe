WITH month_calendar AS (
  SELECT DISTINCT
    date_trunc('month', date_day)::DATE AS month_start,
    last_day(date_day)::DATE AS month_end
  FROM {{ ref('time_spine') }}
),
eligible_member_month AS (
  SELECT
    m.member_id,
    c.month_start,
    c.month_end
  FROM month_calendar c
  CROSS JOIN {{ ref('members') }} m
  WHERE EXISTS (
    SELECT 1
    FROM {{ ref('cards') }} ca
    WHERE ca.member_id = m.member_id
      AND ca.card_type IN ('悦享年卡', '家庭季卡')
      AND ca.valid_from <= c.month_end
      AND c.month_end < ca.valid_until
      AND (ca.ended_at IS NULL OR c.month_end < ca.ended_at)
  )
),
member_month_valid AS (
  SELECT
    member_id,
    date_trunc('month', ordered_at)::DATE AS month_start,
    COUNT(*) AS valid_order_count,
    SUM(net_cents) AS valid_sales_cents
  FROM {{ ref('order_enhanced') }}
  WHERE is_valid
  GROUP BY member_id, date_trunc('month', ordered_at)::DATE
),
eligible_member_month_stats AS (
  SELECT
    e.member_id,
    e.month_start,
    COALESCE(v.valid_order_count, 0) AS valid_order_count,
    COALESCE(v.valid_sales_cents, 0) AS valid_sales_cents
  FROM eligible_member_month e
  LEFT JOIN member_month_valid v
    ON e.member_id = v.member_id AND e.month_start = v.month_start
),
monthly_paid_agg AS (
  SELECT
    month_start,
    COUNT(*) AS eligible_member_count,
    COUNT(*) FILTER (WHERE valid_order_count > 0) AS paid_buyer_count,
    SUM(valid_order_count) AS paid_order_count,
    SUM(valid_sales_cents) AS paid_sales_cents,
    COUNT(*) FILTER (WHERE valid_order_count >= 2) AS paid_repeat_buyer_count
  FROM eligible_member_month_stats
  GROUP BY month_start
)
SELECT
  c.month_start,
  COALESCE(a.eligible_member_count, 0) AS eligible_member_count,
  COALESCE(a.paid_buyer_count, 0) AS paid_buyer_count,
  COALESCE(a.paid_order_count, 0) AS paid_order_count,
  COALESCE(a.paid_sales_cents, 0) AS paid_sales_cents,
  COALESCE(a.paid_repeat_buyer_count, 0) AS paid_repeat_buyer_count
FROM month_calendar c
LEFT JOIN monthly_paid_agg a ON c.month_start = a.month_start