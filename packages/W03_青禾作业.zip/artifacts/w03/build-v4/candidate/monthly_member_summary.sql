WITH calendar AS (
  SELECT DISTINCT CAST(date_trunc('month', CAST(date_day AS DATE)) AS DATE) AS month_start
  FROM {{ ref('time_spine') }}
),
valid_orders AS (
  SELECT order_id,
         member_id,
         CAST(date_trunc('month', ordered_at) AS DATE) AS month_start,
         paid_cents - refund_cents AS net_cents
  FROM {{ ref('orders') }}
  WHERE status = 'paid' AND paid_cents - refund_cents > 0
),
member_month_orders AS (
  SELECT member_id,
         month_start,
         COUNT(*) AS valid_order_count,
         SUM(net_cents) AS net_sales_cents
  FROM valid_orders
  GROUP BY member_id, month_start
),
monthly_base AS (
  SELECT month_start,
         COUNT(*) AS monthly_buyer_count,
         SUM(CASE WHEN valid_order_count >= 2 THEN 1 ELSE 0 END) AS monthly_repeat_buyer_count
  FROM member_month_orders
  GROUP BY month_start
),
cards_in_scope AS (
  SELECT member_id, valid_from, valid_until, ended_at
  FROM {{ ref('cards') }}
  WHERE card_type IN ('悦享年卡', '家庭季卡')
),
eligible_member_month AS (
  SELECT c.month_start,
         cards.member_id
  FROM calendar c
  JOIN cards_in_scope cards
    ON cards.valid_from <= CAST(c.month_start + INTERVAL 1 MONTH - INTERVAL 1 DAY AS DATE)
   AND CAST(c.month_start + INTERVAL 1 MONTH - INTERVAL 1 DAY AS DATE) < cards.valid_until
   AND (cards.ended_at IS NULL OR CAST(c.month_start + INTERVAL 1 MONTH - INTERVAL 1 DAY AS DATE) < cards.ended_at)
  GROUP BY c.month_start, cards.member_id
),
paid_member_month_orders AS (
  SELECT v.member_id,
         v.month_start,
         COUNT(*) AS valid_order_count,
         SUM(v.net_cents) AS net_sales_cents
  FROM valid_orders v
  JOIN eligible_member_month e
    ON v.member_id = e.member_id
   AND v.month_start = e.month_start
  GROUP BY v.member_id, v.month_start
),
monthly_paid_base AS (
  SELECT month_start,
         COUNT(*) AS monthly_paid_buyer_count,
         SUM(valid_order_count) AS monthly_paid_order_count,
         SUM(net_sales_cents) AS monthly_paid_sales_cents,
         SUM(CASE WHEN valid_order_count >= 2 THEN 1 ELSE 0 END) AS monthly_paid_repeat_buyer_count
  FROM paid_member_month_orders
  GROUP BY month_start
)
SELECT c.month_start,
       COALESCE(b.monthly_buyer_count, 0) AS monthly_buyer_count,
       COALESCE(b.monthly_repeat_buyer_count, 0) AS monthly_repeat_buyer_count,
       COALESCE(p.monthly_paid_buyer_count, 0) AS monthly_paid_buyer_count,
       COALESCE(p.monthly_paid_order_count, 0) AS monthly_paid_order_count,
       COALESCE(p.monthly_paid_sales_cents, 0) AS monthly_paid_sales_cents,
       COALESCE(p.monthly_paid_repeat_buyer_count, 0) AS monthly_paid_repeat_buyer_count
FROM calendar c
LEFT JOIN monthly_base b ON c.month_start = b.month_start
LEFT JOIN monthly_paid_base p ON c.month_start = p.month_start