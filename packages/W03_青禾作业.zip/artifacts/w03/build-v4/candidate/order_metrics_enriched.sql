WITH valid_only AS (
  SELECT order_id, member_id, ordered_at
  FROM {{ ref('orders') }}
  WHERE status = 'paid' AND paid_cents - refund_cents > 0
),
ranked_valid AS (
  SELECT order_id,
         ROW_NUMBER() OVER (PARTITION BY member_id ORDER BY ordered_at, order_id) AS valid_rank
  FROM valid_only
)
SELECT o.order_id,
       o.member_id,
       o.store_id,
       m.home_store_id,
       o.ordered_at,
       o.status,
       o.channel,
       o.gross_cents,
       o.paid_cents,
       o.refund_cents,
       o.quantity,
       CASE WHEN o.status = 'paid' AND o.paid_cents - o.refund_cents > 0 THEN 1 ELSE 0 END AS is_valid_order,
       CASE WHEN o.status = 'paid' AND o.refund_cents > 0 THEN 1 ELSE 0 END AS is_refund_order,
       CASE WHEN o.status = 'paid' AND o.refund_cents > 0 AND o.refund_cents < o.paid_cents THEN 1 ELSE 0 END AS is_partial_refund_order,
       CASE WHEN o.status = 'paid' AND o.paid_cents > 0 AND o.refund_cents = o.paid_cents THEN 1 ELSE 0 END AS is_full_refund_order,
       r.valid_rank,
       CASE WHEN r.valid_rank = 1 THEN 1 ELSE 0 END AS is_first_valid_order,
       CASE WHEN r.valid_rank >= 2 THEN 1 ELSE 0 END AS is_repeat_valid_order
FROM {{ ref('orders') }} o
LEFT JOIN {{ ref('members') }} m ON o.member_id = m.member_id
LEFT JOIN ranked_valid r ON o.order_id = r.order_id