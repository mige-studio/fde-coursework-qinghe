"""Independent ledger and identity cross-checks using source files and actual imported rows."""
import csv
from datetime import date
from decimal import Decimal
import json
from pathlib import Path
import sys

import duckdb

sys.path.insert(0,'platform')
from fde_product.w05.identity import resolve

work=Path('work')
prepared=work/'prepared-1'
raw=Path('data/w05-v2')
w04=Path('artifacts/w04/cleaned')
ref=date(2026,9,1)


def read(path):
    with path.open(encoding='utf-8-sig',newline='') as stream:
        yield from csv.DictReader(stream)


def totals(rows):
    counters=[0,0,0]
    for paid,refund,status in rows:
        counters[0]+=1
        counters[1]+=paid
        if status!='已取消' and status!='cancelled':
            counters[2]+=paid-refund
    return counters


def cents(raw_amount):
    return int(Decimal(raw_amount)*100)


recon=json.loads((prepared/'reconciliation.json').read_text())
source_accounts={r['pos_member_id'] for r in read(raw/'pos_member_export.csv')}
pos=[(cents(r['amt_pay']),cents(r['amt_rfd']),r['ord_stat']) for r in read(raw/'pos_order_export.csv')
     if r['hy_id'] in source_accounts and cents(r['amt_pay'])>=cents(r['amt_rfd'])]
crm=[(int(r['paid_cents']),int(r['refund_cents']),r['status']) for r in read(w04/'orders.csv')]
expected=totals(crm+pos)
db=duckdb.connect(str(prepared/'project/data.duckdb'),read_only=True)
actual=list(db.execute("select count(*),sum(paid_cents),sum(paid_cents-refund_cents) filter (where status='paid') from raw_orders").fetchone())
assert actual==expected
assert actual==[recon['orders'][key] for key in ('combined_accepted','paid_cents','net_paid_cents')]
assert recon['orders']['source_CRM_read']==sum(recon['orders'][k] for k in ('CRM_accepted','CRM_quarantined','CRM_deduplicated'))
assert recon['orders']['POS_read']==sum(recon['orders'][k] for k in ('POS_accepted','POS_quarantined'))
mapping=json.loads((prepared/'state/mapping.json').read_text())
frequencies={}
for row in mapping:
    frequencies[row['status']]=frequencies.get(row['status'],0)+1
assert len(mapping)==len({r['source_id'] for r in mapping})==recon['source_accounts']
sample=next(r for r in mapping if r['source_id']=='POS:POS62334')
assert sample['member_id']==next(r for r in mapping if r['source_id']=='CRM:QH10044617')['member_id']
sample_rows=db.execute('select order_id,ordered_at,paid_cents,refund_cents,status from raw_orders where member_id=? order by ordered_at desc',[sample['member_id']]).fetchall()
row=sample_rows[0]
assert row[1]==date(2026,8,31) and row[2:]==(5694,0,'paid')
assert (ref-row[1]).days==1
ignored=next(x for x in recon['identity_findings'] if x['reason']=='INACTIVE_OR_UNCONFIRMED_RECORD')
bad_row=list(read(raw/ignored['source_file']))[ignored['source_row']-1]
assert bad_row['record_id']==ignored['record_id'] and bad_row['status']!='success'
assert not any(ignored['record_id'] in x['evidence_ids'] for x in mapping)
res=dict(expected=dict(crm=totals(crm),pos=totals(pos),combined=expected),actual=actual,identity_status_counts=frequencies,
         excluded_evidence=ignored,sample=dict(member_id=sample['member_id'],order_id=row[0],last_effective_purchase=str(row[1]),dormant_days=1,paid_cents=row[2],refund_cents=row[3]))
(work/'evidence/independent-reconciliation.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n')

# Find existing members at each threshold. The tester will verify via detail.
boundaries=db.execute("""
with latest as (
  select member_id,max(ordered_at) as last_day from raw_orders
  where ordered_at < date '2026-09-01' and status='paid' and paid_cents>refund_cents
  group by member_id
), ranked as (
  select date_diff('day',last_day,date '2026-09-01') as gap_days, min(member_id) as smallest_id
  from latest where starts_with(member_id,'U') group by 1
)
select gap_days,smallest_id from ranked where gap_days in (59,60,61)
""").fetchall()
assert {x[0] for x in boundaries}=={59,60,61}

sids=['CRM:sample-one','CRM:sample-two']
same=dict(left=sids[0],right=sids[1],relation='same',evidence_id='sample-receipt',source_file='synthetic.csv',source_row=1,rule_version='synthetic')
different={**same,'relation':'different','evidence_id':'sample-review','source_row':2}
weak=resolve(sids,[],mapping_version='synthetic')
conflict=resolve(sids,[same,different],mapping_version='synthetic')
assert all(r['status']=='unresolved' for r in weak)
assert all(r['status']=='conflict' and not r['member_id'] for r in conflict)
examples=db.execute("""
with recent as (
  select member_id, max(ordered_at) last_any,
         max(ordered_at) filter(where status='paid' and paid_cents>refund_cents) effective
  from raw_orders group by member_id
)
select distinct o.member_id, o.status, o.ordered_at, r.effective
from raw_orders o join recent r using(member_id)
where o.ordered_at=r.last_any and r.last_any>r.effective
and (o.status='cancelled' or (o.status='paid' and o.paid_cents=o.refund_cents and o.paid_cents>0))
qualify row_number() over (partition by o.status order by o.member_id,o.ordered_at)=1
""").fetchall()
assert {x[1] for x in examples}=={'paid','cancelled'}
out=dict(boundaries=boundaries,excluded_latest_orders=[[mid,status,str(raw_date),str(effective)] for mid,status,raw_date,effective in examples],weak_synthetic=weak,conflict_synthetic=conflict)
(work/'evidence/e/independent-boundary-expectations.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
