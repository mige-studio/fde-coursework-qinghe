"""Validate observed A–E results and assemble the submission report."""
from datetime import datetime
import json
from pathlib import Path

work=Path('work')
report_path=work/'mvp_v1_report.json'
report=json.loads(report_path.read_text())
e=work/'evidence'
f=e/'final'
if not (f/'case-inputs.json').is_file():
    raise SystemExit('W05 final verification has not run')


def load(folder,name):
    return json.loads((folder/(name+'.json')).read_text())


def obs(out,name):
    return next((x for x in out.get('observations',[]) if x['name']==name),{})


def run(group,name):
    p=f/group/(name+'.json')
    if not p.is_file():
        return {}
    return json.loads(p.read_text()).get('output',{})


def grounded(a):
    return a.get('result',{}).get('validation_passed') is True


def item(group,checks):
    c=next(r for r in report['verification_cases'] if r['id']==group.upper())
    c['result']='passed' if all(checks.values()) else 'partial'
    c['findings']=checks
    c['evidence_files']=sorted('evidence/'+p.relative_to(e).as_posix() for p in (f/group).glob('*.json'))


a,b=[run('a',n) for n in ('agent-metric','agent-member')]
metric=obs(a,'query_metrics').get('result',{})
sample=load(f,'case-inputs')['sample']
item('a',{
 '同一会话新旧任务及校验通过':bool(a.get('session_id')) and a.get('session_id')==b.get('session_id') and grounded(a) and grounded(b),
 '全量财务可查且使用本周覆盖':metric.get('status')=='ok' and 'POS' in str(metric.get('coverage_notes',{})) and '未含部分旧' not in a.get('result',{}).get('summary',''),
 '仅当前轮详情和关联证据':set(x['name'] for x in b.get('observations',[]))=={'get_member','member_relations'} and
   obs(b,'get_member').get('result',{}).get('member_id')==sample,
 '合并后最近有效购买确认为1天':load(f/'a','old-card-detail')['dormant_days']==1 and obs(b,'get_member').get('result',{}).get('dormant_days')==1,
})

b_checks={}
expected=load(e/'b','independent-expected')
for store in ('1203','1004'):
    direct=load(f/'b','direct-'+store)
    u=run('b','agent-'+store)
    for name in ('retry-'+store,'retry-'+store+'-contract'):
        retried=run('b',name)
        if grounded(retried):
            u=retried
            break
    found=obs(u,'member_cohort').get('result',{})
    fields=['member_ids','condition_hit_member_ids','recency_condition','range_notice','page']
    b_checks[store+' 两入口同条件、名单、分页与范围一致']=grounded(u) and all(
        ({k:v for k,v in found.get(field,{}).items() if k!='snapshot_token'}==
         {k:v for k,v in direct[field].items() if k!='snapshot_token'}) if field=='page'
        else found.get(field)==direct.get(field) for field in fields)
    b_checks[store+' 名单与独立计算一致']=direct['member_ids']==expected[store]['eligible_ids'] and sorted(direct['condition_hit_member_ids'])==expected[store]['candidate_ids']
    recommendations=u.get('result',{}).get('recommendations',[])
    b_checks[store+' 建议实际引用依据或空名单']=bool(recommendations and recommendations[0].get('knowledge_node_ids')) if direct['member_ids'] else not recommendations
item('b',b_checks)

c_checks={}
for key,channel,status in [('telephone','telephone','blocked'),('unknown','sms','unknown')]:
    d=load(f/'c','detail-'+key)
    u=run('c','agent-'+key)
    retry=run('c','retry-'+key)
    reliable=retry if grounded(retry) else u
    found=obs(reliable,'get_member').get('result',{})
    c_checks[key+' 同一对象的程序与助手工具结果一致']=d['policy']==found.get('policy') and d['policy']['channels'][channel]==status
    c_checks[key+' 回答通过约束及保留依据']=grounded(reliable) and bool(reliable['result'].get('evidence_ids'))
item('c',c_checks)

d_dir=f/'d' if (f/'d/comparison.json').exists() else e/'d'
d_good=(d_dir/'comparison.json').exists() and load(d_dir,'comparison')['passed']
item('d',{'冲突说明带来源且身份和金额一致':d_good})
report['verification_cases'][3]['evidence_files']=['evidence/'+p.relative_to(e).as_posix() for p in sorted(d_dir.glob('*.json'))]

grain=run('e','agent-metric-grain')
retry=run('e','retry-metric-grain')
if grounded(retry):
    grain=retry
summary=grain.get('result',{}).get('summary','')
first=summary.splitlines()[0] if summary else ''
item('e',{
 '59、60、61天与全额退款及取消边界均已复算':all((f/'e'/(n+'.json')).exists() for n in ['boundary-59','boundary-60','boundary-61','boundary-excluded-paid','boundary-excluded-cancelled']),
 '弱线索和有效冲突留待核':(f/'e/independent-boundary-expectations.json').is_file(),
 '三份名单互斥且合并守恒':load(f/'e','partition')['passed'],
 '输出首句为购买财务实体并保留自然人数待核':'购买财务实体' in first and '自然人' in summary and '待' in summary,
 '模型原答通过输出约束':grounded(grain),
})

report['baseline_evidence']=['evidence/a/agent-metric.json','evidence/'+(d_dir/'before.json').relative_to(e).as_posix()]
report['current_evidence']=['evidence/final/a/agent-metric.json','evidence/'+(d_dir/'after.json').relative_to(e).as_posix(),'evidence/independent-reconciliation.json']
report['change_log']=[
 dict(location='W05 指标库 catalog 和业务模型',reason='首轮问数沿用 W04 的旧 POS 未接入说明',
      before_version='work/library',after_version='work/library-v2',
      expected_impact='问数显示当前 CRM 和旧 POS 范围，原指标公式保留',
      evidence=['evidence/a/agent-metric.json','evidence/final/a/agent-metric.json']),
 dict(location='隔离副本 member_attributes',reason='为姓名值冲突提供原字段出处',
      before_version='正式客户规则',after_version='仅隔离验证副本',
      expected_impact='保留冲突原值，同时补足来源账户、字段和行号，与正式批次总额一致',
      evidence=['evidence/'+(d_dir/k).relative_to(e).as_posix() for k in ['before.json','after.json']]),
]
report['scope_and_evidence'].update(
 delivered_capabilities=['统一身份和交易归属','按消费、门店及购买间隔圈选','查看会员、关联记录与适用依据','电话、短信限制及待核'],
 model_and_metric_changes=['承接38项指标，保留原公式和ID','buyer_count 当前显示购买财务实体数','注册关系保留多值，POS 未提供注册门店时保留未知','CRM 及 POS 共195332条接受订单；重新核对金额'],
 material_and_data_sources=['qinghe-w05-v2.0-candidate.2、coverage.json 和配套回执及核查记录','本人 W04 全量清洗结果、查询库和完整模型','W05 客户材料 01–05、正式赋值契约'],
 inferences=['样本老卡交易归属由迁移记录第30426条和有效回执支撑；接入后仅间隔1天'],
 unresolved_impacts=[
  dict(object='12017个未决来源',needed='有效开户和迁移核查及冲突更正',impact='自然人数与涉及未决来源的分母',owner='老周',rerun='映射、订单归属、购买主体相关统计'),
  dict(object='确认为渠道范围待核的勿扰条目',needed='能指回原条目的渠道范围确认',impact='触达建议',owner='小林',rerun='渠道建议与待核详情'),
  dict(object='仅有POS来源的注册关系',needed='有可回查依据的注册门店记录',impact='单店范围',owner='老周',rerun='注册关系、门店圈选')
 ],
 reuse_and_scope_explanation='门店直接查与助手共享同一份配置和规则；沿用本人W04财务清洗与W03指标，当前仅分析和建议；未决自然人需补证。',
 checkpoint_and_ai_usage='使用本人第四周结果，未采用参考 checkpoint。AI 辅助编写客户函数、填写对象配置、独立复算、运行 A～E 与整理证据。'
)
def stamp(path):
    return datetime.fromtimestamp(path.stat().st_mtime).astimezone().isoformat(timespec='seconds')
start=work.parent/'CLAUDE.md'
end=work/'prepared-1/objects/projection.json'
final=work/'prepared-final/objects/projection.json'
report['time_log']=[
 {'stage':stage,'start':stamp(a),'end':stamp(b),'minutes':round((b.stat().st_mtime-a.stat().st_mtime)/60,2),'waiting':waiting}
 for stage,a,b,waiting in [('工作副本与客户实现',start,work/'prepare.json',False),('首轮数据准备和对象生成',work/'mvp_v1_report.json',end,True),('修订覆盖说明后的全量准备',work/'prepare-final.json',final,True)]
 if b.stat().st_mtime>=a.stat().st_mtime
]
out=work/'report.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print([(r['id'],r['result'],[k for k,v in r['findings'].items() if not v]) for r in report['verification_cases']])
