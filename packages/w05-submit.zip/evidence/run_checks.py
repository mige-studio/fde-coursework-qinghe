"""Run the assigned checks against the bound W05 system; preserve actual outputs."""
import collections
import csv
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path.cwd()
PYTHON=sys.executable
WORK=ROOT/'work'
EVIDENCE=Path(os.environ.get('W05_CHECK_EVIDENCE',WORK/'evidence'))
HOME=Path(os.environ.get('W05_CHECK_HOME',WORK/'home-1'))
PREPARED=Path(os.environ.get('W05_CHECK_PREPARED',WORK/'prepared-1'))
REFERENCE='2026-09-01'
SAMPLE_CRM='CRM:QH10044617'
SAMPLE_POS='POS:POS62334'


def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')


def direct(group,label,tool,args,home=HOME):
    request=WORK/f'{label}.json'
    save(request,dict(name=tool,args=args))
    output=EVIDENCE/group/f'{label}.json'
    subprocess.run([PYTHON,'tools/w05.py','service-call','--binding',str(home/'member-binding.json'),
                    '--input',str(request),'--output',str(output)],check=True,capture_output=True,text=True)
    return json.loads(output.read_text())


def agent(group,label,question,session=None):
    args=[PYTHON,'tools/product.py','run','--home',str(HOME),'--text',question]
    if session:
        args+=['--session',session]
    result=subprocess.run(args,capture_output=True,text=True,timeout=620)
    path=EVIDENCE/group/f'{label}.json'
    if result.returncode:
        save(path,dict(question=question,code=result.returncode,stderr=result.stderr[-3500:],stdout=result.stdout[-2000:]))
        return {}
    response=json.loads(result.stdout)
    save(path,dict(question=question,output=response))
    return response


def inputs():
    def lookup(path):
        with path.open(encoding='utf-8-sig',newline='') as stream:
            yield from csv.DictReader(stream)
    prepared=PREPARED
    mapping={r['source_id']:r for r in json.loads((prepared/'state/mapping.json').read_text())}
    policies={r['member_id']:r for r in map(json.loads,(prepared/'state/policies.jsonl').open())}
    members={r['member_id']:r for r in map(json.loads,(prepared/'state/members.jsonl').open())}
    sample=mapping[SAMPLE_CRM]['member_id']
    assert sample and sample==mapping[SAMPLE_POS]['member_id']
    choices={}
    for record in lookup(ROOT/'data/w05-v2/contact_scope_confirmation.csv'):
        mid=mapping[record['source_id']]['member_id']
        if not mid or mid==sample:
            continue
        policy=policies[mid]
        evidence=policy['restriction_evidence']
        if 'telephone' not in choices and record['channel_scope']=='telephone' and policy['channels']['telephone']=='blocked':
            choices['telephone']=mid
        if 'unknown' not in choices and record['channel_scope']=='unknown' and any(x['scope']=='unknown' for x in evidence) and policy['channels']['sms']=='unknown':
            choices['unknown']=mid
    source_names={r['source_id']:(r['system'],r['raw'].get('nm') or r['raw'].get('name'))
                  for r in map(json.loads,(prepared/'state/sources.jsonl').open())}
    conflict=next((m for m in members.values()
                   if m['identity_status']=='verified' and m['display_name'] is None
                   and any(c['field']=='name' for c in m['conflicts'])
                   and any(source_names[s][0]=='CRM' for s in m['source_ids'])),None)
    assert len(choices)==2 and conflict
    return sample,choices,conflict['member_id']


def run_metrics():
    sys.path.insert(0,str(ROOT/'platform'))
    from fde_product.metrics.engine import query_worker
    intent=dict(start='2026-08-01',end=REFERENCE,metrics=['buyer_count'],group_by=[],filters=[])
    result=query_worker(PREPARED/'project',intent)
    save(EVIDENCE/'e/metric-grain.json',result)


def main(stage):
    sample,choices,conflict=inputs()
    save(EVIDENCE/'case-inputs.json',dict(sample=sample,contact=choices,conflict=conflict))
    if stage=='a':
        r=direct('a','old-card-detail','get_member',dict(member_id=sample,channel='sms'))
        relations=direct('a','old-card-relations','member_relations',dict(member_id=sample))
        assert r['dormant_days']==1 and r['dormancy_condition']['matches'] is False
        purchase=[x for x in relations['orders'] if x['provenance']['source_id']==SAMPLE_POS
                  and x['ordered_at']=='2026-08-31' and x['paid_cents']==5694]
        assert len(purchase)==1
        first=agent('a','agent-metric','请用项目指标查询工具查青禾2026年8月全公司整月净销售额，给数值与覆盖范围。')
        session=first.get('session_id')
        if session:
            agent('a','agent-member',f'请查统一会员 {sample}（精确会员ID）的详情及来源账户、关联订单。说明最近有效购买日、截至2026-09-01间隔多少天、是否满60天。保留属性冲突与缺失的区别，只说明这一位。最终请使用 submit_member_analysis 并照工具提交 schema 填写。',session)
    if stage=='b':
        for store in ('1203','1004'):
            request=json.loads((WORK/f'{store}.json').read_text())
            direct('b',f'direct-{store}',request['name'],request['args'])
            agent('b',f'agent-{store}',f'用 member_cohort 查注册门店 {store}，参考日2026-09-01；2025-09-01至2026-09-01（不含）净销售额不少于3000元，距最近有效购买满60天，渠道短信 sms，第一页 offset 0 limit 100。不要另加条件。请逐一查看返回候选人的详情、关联记录、适用知识；对每一位写有证据的建议或说明为何不给建议。空名单照实说明，保持筛选条件和范围。')
    if stage=='c':
        for key,mid in choices.items():
            channel='telephone' if key=='telephone' else 'sms'
            r=direct('c',f'detail-{key}','get_member',dict(member_id=mid,channel=channel))
            assert r['policy']['channels'][channel]==('blocked' if key=='telephone' else 'unknown')
            direct('c',f'relations-{key}','member_relations',dict(member_id=mid))
            question=f'请查询已给定的统一会员 {mid}，使用 get_member（{channel}）、member_relations，并查适用联系限制说明。给出该渠道明确限制或仍待核的依据，保留来源及待核事项。不要执行任何联系。'
            initial=agent('c',f'agent-{key}',question)
            if initial.get('result',{}).get('validation_passed') is not True:
                agent('c',f'retry-{key}',question+' 获取证据后请调用 submit_member_analysis，按最终工具 schema 填写。summary 若有 const 就逐字使用；仅做查询解释，recommendations 留空；渠道待核时保持 incomplete。')
    if stage=='d':
        for key,home in [('before',HOME),('after',WORK/'home-d2')]:
            direct('d',key,'get_member',dict(member_id=conflict,channel='sms'),home)
        a,b=[json.loads((EVIDENCE/'d'/f'{k}.json').read_text()) for k in ('before','after')]
        before,after=a['attributes'],b['attributes']
        before_conflict=next(c for c in before['conflicts'] if c['field']=='name')
        after_conflict=next(c for c in after['conflicts'] if c['field']=='name')
        assert 'sources' not in before_conflict and len(after_conflict['sources'])>=2
        assert {k:v for k,v in after_conflict.items() if k!='sources'}==before_conflict
        assert {k:v for k,v in before.items() if k!='conflicts'}=={k:v for k,v in after.items() if k!='conflicts'}
        assert a['policy']==b['policy'] and a['last_effective_purchase']==b['last_effective_purchase']
        assert (WORK/'prepared-1/reconciliation.json').read_bytes()==(WORK/'prepared-d2/reconciliation.json').read_bytes()
        save(EVIDENCE/'d/comparison.json',dict(passed=True,conflict_sources_displayed=True,identity_and_amounts_preserved=True))
    if stage=='e':
        results={}
        for key in ('dormant','active','none'):
            request=json.loads((WORK/f'{key}.json').read_text())
            results[key]=direct('e',f'direct-{key}',request['name'],request['args'])
        match={k:set(v['condition_hit_member_ids']) for k,v in results.items()}
        assert not (match['dormant'] & match['active'])
        assert match['dormant'] | match['active']==match['none']
        save(EVIDENCE/'e/partition.json',dict(sizes={k:len(v) for k,v in match.items()},passed=True))
        local=json.loads((EVIDENCE/'e/independent-boundary-expectations.json').read_text())
        for days, mid in local['boundaries']:
            r=direct('e',f'boundary-{days}','get_member',dict(member_id=mid))
            assert r['dormant_days']==days and r['dormancy_condition']['matches']==(days>=60)
        for mid,status,raw_date,effective in local['excluded_latest_orders']:
            r=direct('e',f'boundary-excluded-{status}','get_member',dict(member_id=mid))
            assert r['last_effective_purchase']==effective!=raw_date
        run_metrics()
        question='请查青禾2026年8月全公司购买财务实体数 buyer_count，不分组。第一句说明统计单位及数值，并说明精确自然人数是否可以确定。'
        initial=agent('e','agent-metric-grain',question)
        if initial.get('result',{}).get('validation_passed') is not True:
            agent('e','retry-metric-grain',question+' 查到指标后请用 submit_member_analysis 提交。若工具把自然人数标为待核，结果保持 incomplete，完整使用当前 schema 中固定首句与证据。')


if __name__=='__main__':
    main(sys.argv[1])
