"""Qinghe W05 business evidence, attributes and channel rules."""
from collections import defaultdict
from datetime import date
import re
import unicodedata

from fde_product.w05.records import current_records, verify_basis

VERSION = 'qinghe-w05-rules-20261008.1'
MIGRATIONS = 'migration_records.csv'
REVIEWS = 'account_review_records.csv'
OPERATIONS = 'operational_verification.csv'
CONFIRMATIONS = 'contact_scope_confirmation.csv'
WORKBOOK = '小林工作账_勿扰名单.csv'
CHANNELS = ('telephone', 'sms')


def value(raw):
    normalized = unicodedata.normalize('NFKC', raw or '').strip()
    return None if normalized.lower() in ('', 'null', '-', '无', '未知', '未提供') else normalized


def reviewed_scope(materials, section):
    scope = materials['coverage'].get(section, {})
    hashes = materials['manifest']['sha256']
    files = {'crm_member_export.csv', 'pos_member_export.csv'}
    return (set(scope.get('scope_files', [])) == files
            and all(scope.get('file_sha256', {}).get(n) == hashes[n] for n in files)
            and bool(scope.get('reviewed_at'))
            and scope['reviewed_at'] <= materials['reference_date'])


def identity_evidence(accounts, materials):
    """Use verified receipts and scoped review rows as graph inputs."""
    account_ids = {a['source_id'] for a in accounts}
    uncertain = set()
    candidates = []
    findings = []
    as_of = materials['reference_date']
    for filename, states, columns in (
            (MIGRATIONS, ('success',), ('pos_source_id', 'crm_source_id')),
            (REVIEWS, ('current',), ('left_source_id', 'right_source_id'))):
        # Verify the supporting document before permitting an explicit replacement.
        admissible = []
        positions = {}
        for number, row in enumerate(materials[filename], 1):
            positions[row['record_id']] = number
            relation = 'same' if filename == MIGRATIONS else row.get('conclusion')
            valid = verify_basis(row, materials) and row['scope'] == 'specified_accounts'
            if row['status'] in states and not valid:
                findings.append(dict(record_id=row['record_id'], source_file=filename,
                                     source_row=number, reason='UNVERIFIED_BASIS_OR_SCOPE'))
                uncertain.update(row[k] for k in columns)
            admissible.append(row if valid and relation in ('same','different','unresolved')
                              else {**row, 'status':'not_admissible'})
        active, ignored = current_records(admissible, as_of, states=states)
        for finding in ignored:
            findings.append({**finding, 'source_file':filename,
                             'source_row':positions[finding['record_id']]})
        for _, row in active:
            number = positions[row['record_id']]
            left, right = (row[k] for k in columns)
            if left == right or not {left, right} <= account_ids:
                findings.append(dict(record_id=row['record_id'], source_file=filename,
                                     source_row=number, reason='ACCOUNT_MISSING_OR_SELF_REFERENCE'))
                uncertain.update((left, right))
                continue
            relation = 'same' if filename == MIGRATIONS else row['conclusion']
            candidates.append(dict(left=left, right=right, relation=relation,
                                   evidence_id=row['record_id'], source_file=filename,
                                   source_row=number, rule_version=VERSION))
    # The review's explicit exception file identifies accounts without established registrants.
    for _, row in current_records(materials[OPERATIONS], as_of)[0]:
        if row['kind'] == 'abnormal_identity' and row['conclusion'] == 'confirmed' and verify_basis(row, materials):
            uncertain.add(row['source_id'])
    edges = []
    involved = set()
    for edge in candidates:
        pair = {edge['left'], edge['right']}
        if edge['relation'] == 'same' and pair & uncertain:
            edge = {**edge, 'relation':'unresolved'}
        if edge['relation'] in ('same','unresolved'):
            involved.update(pair)
        edges.append(edge)
    singleton = sorted(account_ids - uncertain - involved) if reviewed_scope(materials, 'account_review') else []
    return dict(rule_version=VERSION, evidence=edges, verified_singletons=singleton, findings=findings)


def member_attributes(member_id, source_records):
    values = defaultdict(set)
    sources = []
    for record in sorted(source_records, key=lambda r: r['source_id']):
        raw = record['raw']
        def observe(field, key, item):
            if item is None:
                return
            values[field].add(item)
            sources.append(dict(source_id=record['source_id'], source_file=record['source_file'],
                                source_row=record['source_row'], field=key))
        crm = record['system'] == 'CRM'
        name_field = 'nm' if crm else 'name'
        observe('name', name_field, value(raw.get(name_field)))
        observe('masked_mobile', 'mobile', value(raw.get('mobile')))
        observe('registered_store', 'reg_shop', record.get('registered_store'))
        if crm:
            tier = value(raw.get('lv'))
            observe('tier', 'lv', {'1':'普通','2':'银卡','3':'金卡'}.get(tier, tier))
    names = sorted(values['name'])
    tiers = sorted(values['tier'])
    conflicts = [dict(field=k, values=sorted(values[k]))
                 for k in ('name','masked_mobile','tier') if len(values[k]) > 1]
    for conflict in conflicts:
        if conflict['field']=='name':
            conflict['sources']=[item for item in sources if item['field'] in ('nm','name')]
    return dict(display_name=names[0] if len(names)==1 else None, names=names,
                masked_mobiles=sorted(values['masked_mobile']), tier=tiers[0] if len(tiers)==1 else None,
                conflicts=conflicts, source_ids=sorted(r['source_id'] for r in source_records),
                registered_stores=sorted(values['registered_store']), sources=sources)


def _paper_index(materials):
    """Index evidence once per input batch; per-member policy remains deterministic."""
    cached = materials.get('_qinghe_policy_index')
    if cached is not None:
        return cached
    workbook = defaultdict(list)
    for n, row in enumerate(materials[WORKBOOK], 1):
        if row['登记日期'].replace('/','-') <= materials['reference_date']:
            workbook['CRM:'+row['会员号']].append((n,row['原因']))
    confirms = {}
    active, _ = current_records(materials[CONFIRMATIONS], materials['reference_date'])
    for n, row in active:
        sid = row['source_id']
        try:
            original_row = int(row['original_row'])
        except ValueError:
            continue
        if (row['original_file'] == WORKBOOK and (original_row,row['original_quote']) in workbook[sid]
                and row['scope'] == 'member_after_verified_identity' and verify_basis(row,materials)
                and row['channel_scope'] in ('all',*CHANNELS)):
            confirms.setdefault((sid,original_row), []).append((n,row))
    operations = defaultdict(list)
    for n,row in current_records(materials[OPERATIONS],materials['reference_date'])[0]:
        operations[row['source_id']].append((n,row,verify_basis(row,materials)))
    complete = (reviewed_scope(materials, 'operational_verification')
                and set(materials['coverage']['operational_verification'].get('checked_topics',[]))
                >= {'employee','abnormal_identity'})
    cached = workbook, confirms, operations, complete
    materials['_qinghe_policy_index'] = cached
    return cached


def contact_constraints(member_id, source_records, materials, channel):
    workbook, confirms, operations, complete = _paper_index(materials)
    ids = {r['source_id'] for r in source_records}
    verified = not member_id.startswith('X')
    restrictions, confirmed, pending = [], [], []
    excluded_accounts = set()
    covered_member_exclusion = False
    for rec in source_records:
        sid = rec['source_id']
        def restrict(scope, filename, number, quote, **extra):
            restrictions.append(dict(scope=scope, source_id=sid, source_file=filename,
                                     source_row=number, quote=quote, rule_version=VERSION, **extra))
        tag = rec['raw'].get('tag','')
        for text, scope in (('请勿再联系','all'),('勿打电话','telephone'),('勿发短信','sms')):
            match = re.search(re.escape(text)+r'[^,，;；/|]*',tag)
            if match:
                restrict(scope,rec['source_file'],rec['source_row'],match.group().strip())
        for n, quote in workbook.get(sid, []):
            confirmation = confirms.get((sid,n),[])
            if not confirmation:
                restrict('unknown',WORKBOOK,n,quote)
            for confirmation_row,row in confirmation:
                restrict(row['channel_scope'],WORKBOOK,n,quote,
                         confirmation_file=CONFIRMATIONS, confirmation_row=confirmation_row,
                         confirmation_id=row['record_id'], basis_document_id=row['basis_document_id'])
        for n,row,valid in operations.get(sid,[]):
            confirmed_status = valid and row['conclusion'] == 'confirmed' and row['scope'] in ('member','account')
            scope = row['scope']
            evidence = dict(source_id=sid, source_file=OPERATIONS, source_row=n, kind=row['kind'],
                            verification='confirmed' if confirmed_status else 'unknown',
                            quote=row['summary'], rule_version=VERSION, scope=scope,
                            basis_document_id=row['basis_document_id'])
            if not confirmed_status:
                pending.append(evidence)
                continue
            confirmed.append(evidence)
            if (scope == 'member' or row['kind']=='employee') and verified:
                covered_member_exclusion = True
            else:
                excluded_accounts.add(sid)
    scope_set={r['scope'] for r in restrictions}
    channels={c:'blocked' if 'all' in scope_set or c in scope_set else
              'unknown' if 'unknown' in scope_set or not verified else 'no_known_restriction'
              for c in CHANNELS}
    return dict(member_id=member_id,status='unknown' if not verified or pending or not complete or 'unknown' in scope_set else 'ok',
                channels=channels, restriction_evidence=restrictions, member_excluded=covered_member_exclusion,
                account_exclusions=sorted(excluded_accounts), all_source_accounts_excluded=bool(ids) and ids<=excluded_accounts,
                confirmed_exclusions=confirmed, pending_verifications=pending,
                verification_coverage_complete=complete, actual_contact_authorized=False)
