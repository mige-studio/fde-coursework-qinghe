# 指标修订

## 本次修订的指标 ID 清单

本期 38 项共用来源范围的文字更新。ID 为 order_count, paid_order_count, valid_order_count, cancelled_order_count, refund_order_count, partial_refund_order_count, full_refund_order_count, payment_cents, refund_cents, net_sales_cents, gross_cents, discount_cents, buyer_count, refund_buyer_count, selling_store_count, valid_order_items, avg_order_value, avg_buyer_value, purchase_frequency, refund_amount_rate, cancel_rate, refund_order_rate, discount_rate, items_per_order, new_member_count, first_buyer_count, first_order_sales_cents, first_order_count, repeat_order_count, monthly_buyer_count, monthly_repeat_buyer_count, monthly_repeat_rate, monthly_paid_buyer_count, monthly_paid_order_count, monthly_paid_sales_cents, monthly_paid_repeat_buyer_count, monthly_paid_repeat_rate, monthly_paid_avg_order_value。

## 逐项修订前与修订后定义

全部 38 项原限定课程测试窗口，现额外声明只覆盖新 CRM 及接受记录，部分旧 POS 门店未纳入。new_member_count 另从“按注册日”细化为“按 join_dt 入会日”，避免系统导入账户按建档日重复解释。月内购买、复购、复购率及月末付费六项保留 W03 计算公式、月末资格和账户去重规则。

## 修订依据、来源、原因及适用范围

对应 model_changes.md 的 A、B、D，来源为老周 MSG-06240、原始数据与导入覆盖说明。门店/小程序/商城三个订单渠道按来源保留，使用动态维度。八月逐项复测见 artifacts/w04/metrics_run.json；本次范围说明不会补出旧系统的消费。
