"""Run the 38 existing indicators, each on the same full August window."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'platform'))
from fde_product.metrics.engine import query_worker

if __name__ == '__main__':
    project, start, end = sys.argv[1:4]
    target = ROOT / 'artifacts/w04'
    catalog = json.loads((target / 'library/catalog.json').read_text())
    results = {}
    for metric in catalog:
        key = metric['id']
        intent = dict(metrics=[key], start=start, end=end, group_by=[], filters=[])
        results[key] = query_worker(project, intent)
    (target / 'metrics_run.json').write_text(json.dumps(results, ensure_ascii=False, indent=2)+'\n')
    failed = [key for key, result in results.items() if result['status'] != 'ok']
    print(len(results), failed)
    sys.exit(bool(failed))
