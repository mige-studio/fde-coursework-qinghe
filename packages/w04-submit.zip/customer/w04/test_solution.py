"""Exercise text preservation, dispositions, money conversion and deterministic replay."""
from pathlib import Path
import unittest
import sys
import json

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from solution import adapt, cents, extract_text, local_date, note_category


class CustomerAdapterTests(unittest.TestCase):
    def test_amount_and_dates(self):
        self.assertEqual(cents('79.90'), 7990)
        self.assertEqual(local_date('2025/3/16'), '2025-03-16')
        with self.assertRaises(ValueError):
            local_date('2025-02-30')
        with self.assertRaises(ValueError):
            cents('3.123')

    def test_tags_and_complete_notes(self):
        raw='母婴-0到3岁,卡务-11月办卡，门店留有登记/勿打电话-先留言'
        tags, notes=extract_text(raw,{'母婴-0到3岁'},[',','，','/'])
        self.assertEqual(tags,['母婴-0到3岁'])
        self.assertEqual(notes,['卡务-11月办卡，门店留有登记','勿打电话-先留言'])
        self.assertEqual(note_category(notes[-1]),'触达限制')

    def test_adapter_and_replay(self):
        from solution import FILES
        raw = {'shop':[dict(shop_cd='0001',shop_nm='练习门店',area='华南')],
               'member':[dict(hy_id='A',join_dt='20250316',reg_shop='０００１',lv='普通',stat='0',src_ch='系统导入',create_tm='2025-03-16',tag='夜间购物')],
               'order':[], 'card':[]}
        sale=dict(ord_no='ticket',hy_id='A',shop_cd='0001',ord_tm='2025-03-16',ord_stat='已完成',amt_total='12',amt_pay='10.05',amt_rfd='0',qty='1',ch='商城')
        raw['order']=[sale,sale.copy(),dict(sale,ord_no='refund',amt_rfd='12'),dict(sale,ord_no='missing',hy_id='Z')]
        tables={v:dict(rows=[dict(raw=row,source_row=n+1,source_file=v) for n,row in enumerate(raw[k])]) for k,v in FILES.items()}
        folder=HERE.parents[1]/'artifacts/w04'
        rules=json.loads((folder/'cleaning_rules.yaml').read_text())
        args=(tables,rules,{'rules_dir':str(folder)})
        result=adapt(*args)
        self.assertEqual(result,adapt(*args))
        self.assertEqual(result['record_counts']['order'],dict(read=4,accepted=1,quarantined=2,deduplicated=1))
        self.assertEqual(result['tables']['orders'][0]['paid_cents'],1005)
        self.assertEqual(result['tables']['member_tags'][0]['tag'],'夜间购物')
        self.assertEqual([q['reason_code'] for q in result['tables']['quarantine']],['REFUND_EXCEEDS_PAID','UNLINKED_ACCOUNT'])
        self.assertEqual(json.loads(result['tables']['quarantine'][0]['raw_json']),raw['order'][2])


if __name__ == '__main__':
    unittest.main()
