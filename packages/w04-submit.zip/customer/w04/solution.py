"""Implement customer statistics and decisions here. The harness only handles IO."""


from collections import Counter
from decimal import Decimal
import re


def profile(tables, dictionary, context):
    """Report observed shapes; never infer business meanings from codes."""
    fields, anomalies, differences = [], [], []
    missing = {'', 'NULL', '-', '无'}
    for filename, table in tables.items():
        for field in table['fields']:
            counts = Counter(row['raw'][field].strip() for row in table['rows'])
            absent = sum(counts.pop(marker, 0) for marker in missing)
            total = sum(counts.values()) + absent
            kind = 'text'
            if counts and all(re.fullmatch(r'-?\d+(?:\.\d+)?', value) for value in counts):
                kind = 'numeric text' if field.endswith(('cd', 'id')) or field in ('mobile','reg_shop') else 'number'
            date_field = field in {'join_dt','create_tm','ord_tm','st_dt','ed_dt','stop_dt','open_dt','birth','登记日期','拉名单日期','回访日期','最近购买'}
            if date_field and counts:
                try:
                    parsed_dates = [local_date(v) for v in counts]
                except ValueError:
                    parsed_dates = []
                kind = '本地日期' if parsed_dates else '日期混合格式或无效日期'
            stat = dict(source_file=filename, field=field, inferred_type=kind,
                        total_count=total, missing_count=absent)
            categorical = field in ('lv','stat','src_ch','ord_stat','ch','card_kind','area','shop_stat')
            if categorical and counts:
                stat['distribution'] = [dict(value=k,count=v) for k,v in counts.most_common()]
            elif date_field and counts and parsed_dates:
                stat['range'] = dict(min=min(parsed_dates),max=max(parsed_dates))
            elif kind == 'number':
                nums = [Decimal(k) for k in counts]
                stat['range'] = dict(min=str(min(nums)), max=str(max(nums)))
            else:
                # Text lengths avoid reproducing identifiers, contact information or remarks.
                lens = Counter()
                for k,v in counts.items():
                    lens[len(k)] += v
                stat['distribution'] = [dict(value=f'{k}字符',count=v) for k,v in sorted(lens.items())] or [dict(value='无非空值',count=0)]
            fields.append(stat)

    def issue(file, field, rows, claim, impact):
        if not rows:
            return
        samples = [r['source_row'] for r in rows[:8]]
        actual = f'满足检查条件的原始记录共{len(rows)}条'
        anomalies.append(dict(pattern=f'{field} / {impact} / {actual}',
                              evidence=dict(source_file=file,sample_rows=samples)))
        differences.append(dict(source_file=file,field=field,dictionary_claim=claim,actual=actual,impact=impact))

    members, orders, cards, shops = ('crm_member_export.csv','crm_order_export.csv','crm_card_export.csv','crm_shop.csv')
    def rows(f):
        return tables[f]['rows']
    seen = set()
    duplicates = []
    for row in rows(orders):
        key = row['raw']['ord_no']
        if key in seen:
            duplicates.append(row)
        seen.add(key)
    issue(orders,'ord_no',duplicates,'订单号唯一','重复订单号再次出现，需核实原因与重复处理规则')
    for file, keys in [(orders, ('amt_total','amt_pay','amt_rfd')), (cards, ('pay_amt',))]:
        for key in keys:
            issue(file,key,[r for r in rows(file) if '.' in r['raw'][key]],'整数，单位：分',
                  '带小数点的原始金额；实际单位须核实后转换')
    for key in ('create_tm','reg_dev'):
        if key in tables[members]['fields'] and f'`{key}`' not in dictionary:
            issue(members,key,[r for r in rows(members) if r['raw'][key].strip()],
                  '会员表字段说明未列此字段','新增字段含义和使用范围须找IT核实')
    excessive = []
    for row in rows(orders):
        values = row['raw']
        if re.fullmatch(r'-?\d+(?:\.\d+)?', values['amt_rfd']) and re.fullmatch(r'-?\d+(?:\.\d+)?', values['amt_pay']):
            if Decimal(values['amt_rfd']) > Decimal(values['amt_pay']):
                excessive.append(row['source_row'])
    if excessive:
        anomalies.append(dict(pattern=f'累计退款超过实付：{len(excessive)}条，待单独核查',
                              evidence=dict(source_file=orders,sample_rows=excessive[:8])))
    for file,field,ref,key in [(orders,'hy_id',members,'hy_id'),(orders,'shop_cd',shops,'shop_cd'),(members,'reg_shop',shops,'shop_cd'),(cards,'hy_id',members,'hy_id')]:
        keys = {r['raw'][key] for r in rows(ref)}
        issue(file,field,[r for r in rows(file) if r['raw'][field] not in keys],
              f'参考{ref}中{key}','按原始字段精确匹配不到关联记录，需区分格式与实际缺失')
    for file,field,allowed,claim in [
        (members,'lv',{'1','2','3'},'1 普通，2 银卡，3 金卡'),
        (members,'stat',{'1','2','3'},'1 正常，2 冻结，3 注销'),
        (members,'src_ch',{'门店','小程序','商城'},'门店、小程序、商城'),
        (shops,'area',{'华东','华南','华北'},'华东、华南、华北'),
        (cards,'card_kind',{'悦享卡（年）','家庭季卡','异业联名卡','体验卡'},'悦享卡（年）、家庭季卡、异业联名卡、体验卡')]:
        if claim in dictionary:
            issue(file,field,[r for r in rows(file) if r['raw'][field] not in allowed],claim,'实际标签或编码超出字典所列范围')
    if 'tag' in tables[members]['fields']:
        issue(members,'tag',[r for r in rows(members) if any(c in r['raw']['tag'] for c in ('，',';','；','/',' '))],
              '多个标签用逗号分隔','混合分隔符和整句备注；先匹配运营确认的标签并保留原文')
    return dict(contract_version='w04-0.1.0',data_version=context['data_version'],
                fields=fields,anomalies=anomalies,dictionary_differences=differences)


from datetime import date
import json
from pathlib import Path
import unicodedata


FILES = {'shop':'crm_shop.csv', 'member':'crm_member_export.csv',
         'order':'crm_order_export.csv','card':'crm_card_export.csv'}
TABLES = {'shop':'stores','member':'members','order':'orders','card':'cards'}
FIELDS = {
    'shop': {'store_id':'shop_cd','store_name':'shop_nm','region':'area'},
    'member': {'member_id':'hy_id','registered_at':'join_dt','home_store_id':'reg_shop',
               'tier':'lv','account_status':'stat','registered_channel':'src_ch','created_at':'create_tm'},
    'order': {'order_id':'ord_no','member_id':'hy_id','store_id':'shop_cd','ordered_at':'ord_tm',
              'status':'ord_stat','gross_cents':'amt_total','paid_cents':'amt_pay',
              'refund_cents':'amt_rfd','quantity':'qty','channel':'ch'},
    'card': {'card_id':'card_no','member_id':'hy_id','card_type':'card_kind','valid_from':'st_dt',
             'valid_until':'ed_dt','ended_at':'stop_dt','card_paid_cents':'pay_amt'}}
DATE_FIELDS = {'registered_at','created_at','ordered_at','valid_from','valid_until','ended_at'}
CARD_TYPES = {'悦享卡（年）':'悦享年卡','悦享年卡':'悦享年卡','家庭季卡':'家庭季卡','异业联名卡':'异业联名卡','体验卡':'体验卡'}
ORDER_STATUS = {'已支付':'paid','已完成':'paid','部分退款':'paid','全额退款':'paid','已取消':'cancelled'}


def local_date(value):
    plain = unicodedata.normalize('NFKC',value.strip()).split(' ')[0].split('T')[0]
    plain = plain.replace('年','-').replace('月','-').replace('日','').replace('/','-').replace('.','-')
    if re.fullmatch(r'\d{8}', plain):
        plain = f'{plain[:4]}-{plain[4:6]}-{plain[6:]}'
    try:
        return date(*map(int,plain.split('-'))).isoformat()
    except (TypeError,ValueError):
        raise ValueError('date') from None


def cents(value):
    from decimal import InvalidOperation
    try:
        scaled=Decimal(value)*100
        if scaled.is_finite() and scaled>=0 and scaled==scaled.to_integral_value():
            return int(scaled)
    except InvalidOperation:
        pass
    raise ValueError('invalid')


def note_category(value):
    if re.search(r'勿|不要.{0,4}(打|发|联|拨)|别.{0,3}(打|发|联)|拒接|拒收|禁止|不再联系|别再联系|拒绝.{0,4}(营销|联系)|不要营销',value):
        return '触达限制'
    if re.search('办卡|卡务|续卡|元卡|老卡|换卡',value):return '卡务'
    if re.search('电话|微信|号码|联系状态|没接|回复|打不通',value):return '联系状态'
    if re.search('熟客|老客户|客户关系|店长认识|朋友介绍',value):return '客户关系'
    return '其他'


def extract_text(raw, legal, delimiters):
    # Split at a tag or a new note. Keep punctuation inside a prose note.
    separators=''.join(re.escape(s) for s in delimiters)
    parts=re.split(f'([{separators}]+)',raw)
    tags, notes=[],[]
    note=''
    for i in range(0,len(parts),2):
        token=parts[i].strip()
        if not token: continue
        sep=parts[i-1] if i else ''
        if token in legal:
            if note: notes.append(note);note=''
            if token not in tags: tags.append(token)
        else:
            starts=bool(re.match(r'[^，,。；; /]{1,8}[-－]|勿|别再|不要|卡务|续卡|\d+元卡',token))
            if note and (starts or '。' in note[-1:] or sep.strip() in (';','；','/','|')):
                notes.append(note);note=''
            note=note+sep+token if note else token
    if note:notes.append(note)
    return tags,list(dict.fromkeys(notes))


def adapt(tables,rules,context):
    cfg={r['rule_id']:r for r in rules['abnormal_records']}
    invalid={field:set(r['values']) for r in rules['invalid_values'] if r['action']=='null' for field in r['source_fields']}
    if cfg['money']['action']!='normalize' or cfg['duplicate']['action']!='deduplicate':
        raise ValueError('Unsupported normalization policy')
    tag_cfg=rules['tag_cleaning']
    legal=set((Path(context['rules_dir'])/tag_cfg['legal_tags_source']).read_text().splitlines())
    out={k:[] for k in [*TABLES.values(),'member_tags','member_notes','quarantine']}
    counts={};samples={};stores=set();members=set()
    for kind,filename in FILES.items():
        rows=tables[filename]['rows']; cols=FIELDS[kind]; pk=next(iter(cols.values()))
        counts[kind]=count=dict(read=len(rows),accepted=0,quarantined=0,deduplicated=0)
        identifiers={}; conflicts=set()
        for row in rows:
            raw=row['raw'];key=unicodedata.normalize('NFKC',raw[pk]).strip()
            if key in identifiers and identifiers[key]!=raw:conflicts.add(key)
            else:identifiers[key]=raw
        seen=set()
        for row in rows:
            raw=row['raw'];number=row['source_row']
            m={k:v.strip() for k,v in ((target,raw[source]) for target,source in cols.items())}
            key=unicodedata.normalize('NFKC',raw[pk]).strip()
            try:
                if not key:raise ValueError('invalid')
                if key in conflicts:raise ValueError('conflict')
                if key in seen:
                    count['deduplicated']+=1
                    continue
                seen.add(key)
                for k in m:
                    if k.endswith('_id'):m[k]=unicodedata.normalize('NFKC',m[k])
                    if k in DATE_FIELDS:
                        if k=='ended_at' and m[k] in invalid['stop_dt']:m[k]=''
                        else:m[k]=local_date(m[k])
                    if k.endswith('_cents'):m[k]=cents(m[k])
                if kind=='shop':stores.add(m['store_id'])
                if kind=='member':
                    if m['home_store_id'] not in stores:raise ValueError('store')
                    m['tier']={'1':'普通','2':'银卡','3':'金卡'}.get(m['tier'],m['tier'])
                    m['account_status']={'0':'未激活','1':'活跃','2':'冻结','3':'注销'}.get(m['account_status'])
                    if not m['account_status'] or m['registered_channel'] not in ('小程序','商城','门店','系统导入'):raise ValueError('invalid')
                    members.add(key)
                    if raw['tag'].strip() not in invalid['tag']:
                        tags,notes=extract_text(raw['tag'],legal,tag_cfg['delimiters'])
                        out['member_tags'].extend(dict(member_id=key,tag=t) for t in tags)
                        for note in notes:
                            out['member_notes'].append(dict(member_id=key,source_file=filename,source_row=number,source_field='tag',raw_text=raw['tag'],note_text=note,category=note_category(note)))
                if kind in ('card','order') and m['member_id'] not in members:raise ValueError('orphan')
                if kind=='order':
                    if m['store_id'] not in stores:raise ValueError('store')
                    if m['refund_cents']>m['paid_cents']:raise ValueError('refund')
                    if m['status'] not in ORDER_STATUS or m['channel'] not in ('门店','小程序','商城') or not m['quantity'].isdigit():raise ValueError('invalid')
                    m.update(status=ORDER_STATUS[m['status']],quantity=int(m['quantity']))
                if kind=='card':
                    if m['card_type'] not in CARD_TYPES:raise ValueError('card')
                    if m['valid_until']<m['valid_from'] or (m['ended_at'] and m['ended_at']<m['valid_from']):raise ValueError('date')
                    m['card_type']=CARD_TYPES[m['card_type']]
            except ValueError as exc:
                rule=cfg[str(exc)]
                if rule['action']!='quarantine':raise
                code=rule['reason_code'];count['quarantined']+=1
                out['quarantine'].append(dict(record_type=kind,source_file=filename,source_row=number,reason_code=code,raw_json=json.dumps(raw,ensure_ascii=False)))
                samples.setdefault('quarantined',dict(source_file=filename,source_row=number,status='quarantined',destination=f'quarantine.csv 第{len(out["quarantine"])}条',reason=code))
                continue
            count['accepted']+=1
            out[TABLES[kind]].append(m)
            if kind=='order':
                samples.setdefault('accepted',dict(source_file=filename,source_row=number,status='accepted',destination=f'orders.csv 第{count["accepted"]}条',reason='编号、关联、金额与日期核对通过'))
    mapping=[]
    for kind,cols in FIELDS.items():
        for target,source in cols.items():
            transformation=('按元解析并转整数分' if target.endswith('_cents') else '本地日历日' if target in DATE_FIELDS else '对照代码及业务值，去除字段外围空白')
            mapping.append(dict(source_file=FILES[kind],source_fields=[source],target=TABLES[kind]+'.'+target,transformation=transformation))
    for target in ('member_notes.raw_text','member_tags.tag'):
        mapping.append(dict(source_file=FILES['member'],source_fields=['tag'],target=target,transformation='仅确认标签进入标签表，备注保留原文与行号'))
    coverage=dict(source='仅新CRM，部分门店旧POS消费未导出。运营工作账仅用于核对，不能作为可拨打授权。',time_range=dict(start='2024-09-01',end_exclusive='2026-09-01'),quarantined={k:v['quarantined'] for k,v in counts.items()})
    return dict(tables=out,record_counts=counts,samples=list(samples.values()),field_mapping=mapping,coverage_notes=coverage)
def reconcile(payload):
    meta=payload['metadata']
    first, second=payload['first'], payload['second']
    same=first['counts']==second['counts'] and first['table_sha256']==second['table_sha256']
    checks=[]
    for kind, filename in FILES.items():
        count=meta['record_counts'][kind]
        source_count=len(payload['source'][filename]['rows'])
        actual=first['counts']['raw_'+TABLES[kind]]
        balanced=(source_count==count['read']==sum(count[k] for k in ('accepted','quarantined','deduplicated'))
                  and actual==count['accepted'])
        checks.append(dict(record_type=kind,**count,reconciliation=dict(balanced=balanced,evidence=
            f"读入 {source_count}；接受 {actual}、隔离 {count['quarantined']}、去重 {count['deduplicated']}。")))
    clean=payload['cleaned']['orders.csv']['rows']
    accepted={r['raw']['order_id'] for r in clean}
    originals={}
    for r in payload['source'][FILES['order']]['rows']:
        raw=r['raw']
        key=unicodedata.normalize('NFKC',raw['ord_no']).strip()
        if key in accepted: originals.setdefault(key,raw)
    comparisons={}
    money_ok=True
    for source,target in [('amt_total','gross_cents'),('amt_pay','paid_cents'),('amt_rfd','refund_cents')]:
        raw_total=sum(cents(r[source]) for r in originals.values())
        clean_total=sum(int(r['raw'][target]) for r in clean)
        comparisons[target]=[raw_total,clean_total]
        money_ok=money_ok and raw_total==clean_total
    passed=(same and money_ok and len(originals)==len(clean)==first['order_count']==second['order_count']
            and comparisons['paid_cents'][0]==first['paid_cents']==second['paid_cents']
            and all(x['reconciliation']['balanced'] for x in checks))
    return dict(contract_version='w04-0.1.0',data_version=payload['manifest']['id'],
                field_mapping=meta['field_mapping'],record_counts=checks,samples=meta['samples'],
                repeat_import=dict(first_run_id='/'.join(Path(payload['first_run_id']).parts[-2:]),second_run_id='/'.join(Path(payload['second_run_id']).parts[-2:]),
                                   before=first['counts'],after=second['counts'],row_counts_equal=first['counts']==second['counts']),
                test_result=dict(passed=passed,details=f'金额按接受订单逐号回源核对，原始/清洗金额（分）{comparisons}。两次全量导入逐表内容摘要一致={same}。'))
